package com.example.studybridge

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AgreementActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.agreement)  // agreement.xml 레이아웃을 설정합니다.
    }
}
